1、为什么用top看到的cpu占用率是98%左右，但是用busybox或者ssh工具（mobaxterm）看到的占用率仅有50%？

<img src="Q-SSH_Honeypot.assets/image-20240627132754670.png" alt="image-20240627132754670" style="zoom:50%;" />

<img src="Q-SSH_Honeypot.assets/image-20240627132730151.png" alt="image-20240627132730151" style="zoom:50%;" />

![image-20240627132805323](Q-SSH_Honeypot.assets/image-20240627132805323.png)

2、定时任务/etc/cron.d下有一个0hourly定时执行/etc/cron.hourly文件，查看其下所有文件，gcc.sh和0anacron感觉都是正常的，仅twpydvkwtnog.sh文件看起来有问题。

<img src="Q-SSH_Honeypot.assets/image-20240627134057196.png" alt="image-20240627134057196" style="zoom:50%;" />

<img src="Q-SSH_Honeypot.assets/image-20240627134616327.png" alt="image-20240627134616327" style="zoom: 50%;" />

twpydvkwtnog.sh将/bin/twpydvkwtnog原地复制一份并改名为whdlwwenev，但是不知道最后一行的"/bin/whdlwwenev"是什么意思呢？实际测试发现，在执行该脚本后/bin/twpydvkwtnog并没有复制出一份并改名为whdlwwenev，这是为什么呢？

而且有意思的是还有一个文件名是twpydvkwtnog的反转即gontwkdypwt,他俩的大小一模一样

<img src="Q-SSH_Honeypot.assets/image-20240627134713301.png" alt="image-20240627134713301" style="zoom: 50%;" />

![image-20240627135430864](Q-SSH_Honeypot.assets/image-20240627135430864.png)

3、在执行twpydvkwtnog文件后原有的twpydvkwtnog相关的文件都变成了zradiyeiykt，包括twpydvkwtnog的反转名文件gontwkdypwt也变成了zradiyeiykt的反转名文件tkyieyidarz。（再多次执行该文件也是同样的文件变名字但功能不变，且反转名文件与正常名文件有同样的执行效果。不仅如此，直接在删除该.sh脚本和可执行文件的结果和执行可执行文件的结果是相同的）

但是占用CPU的进程ygljglkjgfg0并没有丝毫变化，还是处于运行状态。

![image-20240627140115019](Q-SSH_Honeypot.assets/image-20240627140115019.png)

4、用ps看不到1201这个进程，但是busybox可以，这是攻击者修改了ps工具吗

<img src="Q-SSH_Honeypot.assets/image-20240627142732330.png" alt="image-20240627142732330" style="zoom:50%;" />

用ll /proc/pid_id/exe查看到其

![image-20240627143606242](Q-SSH_Honeypot.assets/image-20240627143606242.png)